const { idlFactory } = require('./admin.did.js');

module.exports = { idlFactory };
