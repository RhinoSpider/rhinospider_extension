const idlFactory = ({ IDL }) => {
  const ContentIdentifiers = IDL.Record({
    'selectors' : IDL.Vec(IDL.Text),
    'keywords' : IDL.Vec(IDL.Text),
  });
  const ExtractionRules = IDL.Record({
    'fields' : IDL.Vec(
      IDL.Record({
        'name' : IDL.Text,
        'aiPrompt' : IDL.Opt(IDL.Text),
        'required' : IDL.Bool,
        'fieldType' : IDL.Text,
      })
    ),
    'customPrompt' : IDL.Opt(IDL.Text),
  });
  const Topic = IDL.Record({
    'id' : IDL.Text,
    'status' : IDL.Text,
    'name' : IDL.Text,
    'createdAt' : IDL.Int,
    'description' : IDL.Text,
    'urlGenerationStrategy' : IDL.Text,
    'urlPatterns' : IDL.Vec(IDL.Text),
    'articleUrlPatterns' : IDL.Opt(IDL.Vec(IDL.Text)),
    'paginationPatterns' : IDL.Opt(IDL.Vec(IDL.Text)),
    'excludePatterns' : IDL.Opt(IDL.Vec(IDL.Text)),
    'contentIdentifiers' : IDL.Opt(ContentIdentifiers),
    'extractionRules' : ExtractionRules,
    'siteTypeClassification' : IDL.Opt(IDL.Text),
  });
  const Error = IDL.Variant({
    'InvalidInput' : IDL.Text,
    'SystemError' : IDL.Text,
    'NotFound' : IDL.Null,
    'NotAuthorized' : IDL.Null,
    'AlreadyExists' : IDL.Null,
  });
  const Result = IDL.Variant({ 'ok' : IDL.Vec(Topic), 'err' : Error });
  
  return IDL.Service({
    'getTopics' : IDL.Func([], [Result], ['query']),
    'getTopic' : IDL.Func([IDL.Text], [IDL.Variant({ 'ok' : Topic, 'err' : Error })], ['query']),
  });
};

const init = ({ IDL }) => { return []; };

module.exports = { idlFactory, init };
