const { searchForUrls } = require('./searchHandler');
const NodeCache = require('node-cache');

// Cache to store pre-fetched URLs
const urlCache = new NodeCache({ stdTTL: 86400, checkperiod: 600 });

/**
 * Initialize URL cache with real search results for common topics
 * This ensures we have real URLs ready when the extension requests them
 */
async function initializeUrlCache() {
  console.log('Initializing URL cache with real search results...');
  
  // Common topics that users might be interested in
  // These are just examples - the extension will provide its own topics
  const commonTopics = [
    { id: 'js-prog', name: 'JavaScript Programming', keywords: ['tutorial', 'guide', 'examples'] },
    { id: 'ml-ai', name: 'Machine Learning', keywords: ['beginners', 'python', 'tensorflow'] },
    { id: 'web-dev', name: 'Web Development', keywords: ['html', 'css', 'responsive'] },
    { id: 'data-sci', name: 'Data Science', keywords: ['analysis', 'visualization', 'python'] },
    { id: 'cyber-sec', name: 'Cybersecurity', keywords: ['basics', 'protection', 'threats'] }
  ];
  
  // Fetch real URLs for each topic
  for (const topic of commonTopics) {
    try {
      console.log(`Fetching real URLs for topic: ${topic.name}`);
      const urls = await searchForUrls(topic.name, topic.keywords, 0);
      
      if (urls && urls.length > 0) {
        urlCache.set(topic.id, urls);
        console.log(`✅ Cached ${urls.length} real URLs for topic: ${topic.name}`);
        
        // Log a few sample URLs to verify they're real
        if (urls.length > 0) {
          console.log('Sample URLs:');
          urls.slice(0, 3).forEach((url, index) => {
            console.log(`  ${index + 1}. ${url}`);
          });
        }
      } else {
        console.log(`⚠️ No URLs found for topic: ${topic.name}`);
      }
    } catch (error) {
      console.error(`Error fetching URLs for topic ${topic.name}:`, error.message);
    }
  }
  
  console.log('URL cache initialization completed');
  return urlCache;
}

/**
 * Get cached URLs for a topic
 * @param {string} topicId - Topic ID
 * @returns {string[]} - Array of URLs or empty array if none found
 */
function getCachedUrls(topicId) {
  return urlCache.get(topicId) || [];
}

module.exports = {
  initializeUrlCache,
  getCachedUrls,
  urlCache
};
