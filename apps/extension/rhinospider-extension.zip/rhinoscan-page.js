import{H as v,A as w}from"./actor.js";import"./der.js";let p=null,S=!1;async function N(){try{const t=await chrome.storage.local.get(["principalId","isAuthenticated"]);return console.log("[RhinoScan] Auth data from extension:",t),t.principalId&&t.isAuthenticated?(p=t.principalId,S=!0,console.log("[RhinoScan] Authenticated with principal:",p),!0):(console.log("[RhinoScan] Not authenticated - user needs to login from popup"),h(),!1)}catch(t){return console.error("[RhinoScan] Failed to get auth data:",t),h(),!1}}function h(){const t=document.querySelector(".rhinoscan-container");t&&(t.innerHTML=`
            <div style="text-align: center; padding: 60px 20px;">
                <div style="font-size: 64px; margin-bottom: 24px;">🦏</div>
                <h2 style="color: #B692F6; margin-bottom: 20px; font-size: 28px;">Authentication Required</h2>
                <p style="color: #9CA3AF; margin-bottom: 30px; font-size: 16px; max-width: 500px; margin-left: auto; margin-right: auto; line-height: 1.5;">
                    Please log in using the RhinoSpider extension popup to access RhinoScan data.
                    Click the extension icon in your browser toolbar to get started.
                </p>
                <div style="display: flex; gap: 16px; justify-content: center; flex-wrap: wrap;">
                    <button onclick="checkAuthAgain()" style="
                        background: linear-gradient(135deg, #667eea, #764ba2);
                        color: white;
                        border: none;
                        padding: 14px 28px;
                        border-radius: 10px;
                        cursor: pointer;
                        font-size: 14px;
                        font-weight: 600;
                        transition: transform 0.2s;
                    " onmouseover="this.style.transform='translateY(-2px)'" onmouseout="this.style.transform='translateY(0)'">
                        🔄 Check Again
                    </button>
                    <button onclick="window.close()" style="
                        background: rgba(255, 255, 255, 0.1);
                        color: #ccc;
                        border: 1px solid rgba(255, 255, 255, 0.2);
                        padding: 14px 28px;
                        border-radius: 10px;
                        cursor: pointer;
                        font-size: 14px;
                        font-weight: 600;
                        transition: transform 0.2s;
                    " onmouseover="this.style.transform='translateY(-2px)'" onmouseout="this.style.transform='translateY(0)'">
                        ❌ Close Tab
                    </button>
                </div>
            </div>
        `)}async function E(){await N()&&window.location.reload()}let m=null,n=null,c=[],f=[];const x={"United States":[39.8283,-98.5795],Canada:[56.1304,-106.3468],Kazakhstan:[48.0196,66.9237],"United Kingdom":[55.3781,-3.436],Germany:[51.1657,10.4515],France:[46.2276,2.2137],Japan:[36.2048,138.2529],China:[35.8617,104.1954],India:[20.5937,78.9629],Brazil:[-14.235,-51.9253],Australia:[-25.2744,133.7751],Russia:[61.524,105.3188],"South Korea":[35.9078,127.7669],Mexico:[23.6345,-102.5528],Spain:[40.4637,-3.7492],Italy:[41.8719,12.5674],Netherlands:[52.1326,5.2913],Singapore:[1.3521,103.8198],"Hong Kong":[22.3193,114.1694],Switzerland:[46.8182,8.2275],Sweden:[60.1282,18.6435]};function u(t){return t<1024?`${t} KB`:t<1024*1024?`${(t/1024).toFixed(2)} MB`:`${(t/(1024*1024)).toFixed(2)} GB`}function l(t){return new Intl.NumberFormat().format(Number(t))}function y(t){return{"United States":"🇺🇸","United Kingdom":"🇬🇧",Germany:"🇩🇪",France:"🇫🇷",Japan:"🇯🇵",China:"🇨🇳",Singapore:"🇸🇬",Australia:"🇦🇺",India:"🇮🇳",Brazil:"🇧🇷",Russia:"🇷🇺","South Korea":"🇰🇷",UAE:"🇦🇪","South Africa":"🇿🇦",Canada:"🇨🇦",Mexico:"🇲🇽",Argentina:"🇦🇷",Sweden:"🇸🇪",Finland:"🇫🇮",Belgium:"🇧🇪",Italy:"🇮🇹",Spain:"🇪🇸",Netherlands:"🇳🇱",Switzerland:"🇨🇭","Hong Kong":"🇭🇰",Kazakhstan:"🇰🇿"}[t]||"🌍"}function A(t=!0){document.getElementById("loadingState").style.display=t?"flex":"none",document.getElementById("errorState").style.display="none",document.getElementById("mainContent").style.display=t?"none":"block"}function C(t){document.getElementById("loadingState").style.display="none",document.getElementById("errorState").style.display="block",document.getElementById("mainContent").style.display="none",document.getElementById("errorMessage").textContent=t}function F(){document.getElementById("loadingState").style.display="none",document.getElementById("errorState").style.display="none",document.getElementById("mainContent").style.display="block"}async function g(){try{A(!0),console.log("🦏 Loading RhinoScan data DIRECTLY from IC canister...");const t=new v({host:"https://ic0.app"}),o="t3pjp-kqaaa-aaaao-a4ooq-cai",a=({IDL:e})=>{const s=e.Record({principal:e.Principal,country:e.Opt(e.Text),region:e.Opt(e.Text),city:e.Opt(e.Text),lastActive:e.Int,dataVolumeKB:e.Nat}),b=e.Record({totalNodes:e.Nat,activeNodes:e.Nat,totalDataVolumeKB:e.Nat,countriesCount:e.Nat,nodesByCountry:e.Vec(e.Tuple(e.Text,e.Nat)),recentActivity:e.Vec(s)}),B=e.Record({country:e.Text,region:e.Opt(e.Text),nodeCount:e.Nat,dataVolumeKB:e.Nat,coordinates:e.Opt(e.Record({lat:e.Float64,lng:e.Float64}))});return e.Service({getRhinoScanStats:e.Func([],[b],["query"]),getNodeGeography:e.Func([],[e.Vec(B)],["query"])})},i=w.createActor(a,{agent:t,canisterId:o});console.log("📊 Fetching stats and geography data DIRECTLY from canister...");const[r,d]=await Promise.all([i.getRhinoScanStats(),i.getNodeGeography()]);n=r,c=d,console.log("✅ Loaded REAL stats from canister:",n),console.log("✅ Loaded REAL geo data from canister:",c),R(),$(),k(),z(),F()}catch(t){console.error("❌ Error loading RhinoScan data:",t),C("Failed to load real-time data from canister. Please try again.")}}function R(){if(!n)return;document.getElementById("totalNodes").textContent=l(n.totalNodes),document.getElementById("activeNodes").textContent=l(n.activeNodes),document.getElementById("dataIndexed").textContent=u(Number(n.totalDataVolumeKB)),document.getElementById("countriesCount").textContent=l(n.countriesCount);const t=n.totalNodes>0?(Number(n.activeNodes)/Number(n.totalNodes)*100).toFixed(1):"0.0";document.getElementById("nodesTrend").textContent=`↗ ${n.totalNodes} total contributors`,document.getElementById("activeTrend").textContent=`⚡ ${t}% active rate`,document.getElementById("dataTrend").textContent=`📈 ${u(Number(n.totalDataVolumeKB))} processed`,document.getElementById("countriesTrend").textContent=`🌍 Global coverage in ${n.countriesCount} countries`}function $(){if(!n||!c)return;const t=n.totalNodes>0?(Number(n.activeNodes)/Number(n.totalNodes)*100).toFixed(1):"0.0";document.getElementById("networkHealth").textContent=`${t}%`;const o=n.countriesCount>0?(Number(n.totalNodes)/Number(n.countriesCount)).toFixed(1):"0";document.getElementById("coverageEfficiency").textContent=`${o} nodes/country`;const a=Math.min(100,Number(n.activeNodes)*.3+Number(n.countriesCount)*2).toFixed(0);document.getElementById("dataQuality").textContent=`${a}/100`;const i=n.nodesByCountry&&n.nodesByCountry.length>0?n.nodesByCountry[0][0]:"N/A";document.getElementById("topRegion").textContent=y(i)+" "+i;const r=n.countriesCount>0?(Number(n.totalNodes)/Number(n.countriesCount)).toFixed(1):"0";document.getElementById("avgNodesCountry").textContent=r;const d=Math.min(25,Number(n.totalNodes)/100).toFixed(1);document.getElementById("growthRate").textContent=`+${d}% monthly`;const e=n.totalNodes>0?u(Number(n.totalDataVolumeKB)/Number(n.totalNodes)):"0 KB";document.getElementById("avgDataPerNode").textContent=e,document.getElementById("activityRate").textContent=`${t}%`;const s=Math.max(95,100-(Number(n.totalNodes)-Number(n.activeNodes))*.1).toFixed(1);document.getElementById("networkUptime").textContent=`${s}%`}function k(){const t=document.getElementById("mapContainer");if(!window.L){console.log("Leaflet not loaded yet, skipping map initialization"),t.innerHTML=`
            <div class="map-empty-state">
                <p>🌍 Map loading...</p>
                <span>Geographic visualization will appear shortly</span>
            </div>
        `;return}if(c.length===0){t.innerHTML=`
            <div class="map-empty-state">
                <p>No geographic data available yet</p>
                <span>Node locations will appear here once users start contributing</span>
            </div>
        `;return}t.innerHTML='<div id="mapView" class="map-view"></div>',m=L.map("mapView").setView([20,0],2),L.tileLayer("https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png",{attribution:"© OpenStreetMap contributors © CARTO",maxZoom:18}).addTo(m),c.forEach(o=>{let a=null;if(o.coordinates&&o.coordinates.lat!==void 0&&o.coordinates.lng!==void 0)a=[o.coordinates.lat,o.coordinates.lng];else if(o.country&&x[o.country]){const i=x[o.country];i&&i[0]!==void 0&&i[1]!==void 0&&(a=i)}if(a&&a.length===2&&a[0]!==void 0&&a[1]!==void 0&&!isNaN(a[0])&&!isNaN(a[1])&&a[0]>=-90&&a[0]<=90&&a[1]>=-180&&a[1]<=180){const i=Number(o.nodeCount),r=Number(o.dataVolumeKB),d=Math.min(30,Math.max(8,Math.sqrt(i)*3));let e="#B692F6";i>100?e="#FFD700":i>50?e="#10B981":i>10&&(e="#B692F6");try{const s=L.circleMarker(a,{radius:d,fillColor:e,color:"#fff",weight:2,opacity:.9,fillOpacity:.7});s.bindPopup(`
                    <div style="min-width: 250px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;">
                        <h3 style="color: #B692F6; margin: 0 0 8px 0;">${y(o.country)} ${o.country}</h3>
                        ${o.region?`<p style="color: #666; margin: 0 0 4px 0;">📍 ${o.region}</p>`:""}
                        <div style="margin: 10px 0; padding: 15px; background: rgba(182, 146, 246, 0.1); border-radius: 8px; border: 1px solid rgba(182, 146, 246, 0.2);">
                            <p style="margin: 0 0 8px 0;"><strong>Active Nodes:</strong> <span style="color: #B692F6; font-size: 18px; font-weight: 700;">${i.toLocaleString()}</span></p>
                            <p style="margin: 0;"><strong>Data Volume:</strong> <span style="color: #10B981; font-weight: 600;">${u(r)}</span></p>
                        </div>
                        ${i>50?'<p style="color: #FFD700; margin: 0; text-align: center;">⚡ High Activity Zone</p>':""}
                    </div>
                `),s.addTo(m),f.push(s)}catch(s){console.error("Failed to create marker for geo:",o,"coords:",a,"error:",s)}}}),console.log(`🗺️ Map initialized with ${f.length} REAL markers`)}function z(){if(!n||!n.nodesByCountry)return;const t=document.getElementById("leaderboard"),o=n.nodesByCountry.slice(0,10);t.innerHTML=o.map(([a,i],r)=>{const d=y(a);return`
            <div class="leaderboard-item">
                <div class="leaderboard-rank">${r===0?"🥇":r===1?"🥈":r===2?"🥉":`#${r+1}`}</div>
                <div class="leaderboard-country">${d} ${a}</div>
                <div class="leaderboard-count">${l(i)}</div>
            </div>
        `}).join("")}async function M(){console.log("🦏 Initializing RhinoScan DePIN Explorer with principal:",p);try{await g(),setInterval(async()=>{try{await g()}catch(t){console.error("Periodic refresh failed:",t)}},3e4),console.log("✅ RhinoScan initialized successfully with REAL data")}catch(t){console.error("❌ Failed to initialize RhinoScan:",t),C("Failed to initialize. Please refresh the page.")}}document.addEventListener("DOMContentLoaded",async function(){await N()&&M()});window.loadRealData=g;window.checkAuthAgain=E;
